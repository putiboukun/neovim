vim.env.http_proxy = "http://naoyoshi.yamamoto.y9%40mail.toray:F065807_nya@webproxy:8080"
vim.env.https_proxy = "http://naoyoshi.yamamoto.y9%40mail.toray:F065807_nya@webproxy:8080"


-- lazy.nvim boot strap
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
    vim.fn.system({
        "git",
        "clone",
        "--filter=blob:none",
        "https://github.com/folke/lazy.nvim.git",
        "--branch=stable",
        lazypath,
    })
end
vim.opt.rtp:prepend(lazypath)

-- local plugins
local plugins = {
    { import = "plugins" },
}

-- local opts
local opts = {
    root = vim.fn.stdpath("data") .. "/lazy",
    lockfile = vim.fn.stdpath("config") .. "/lazy-lock.json",
    concurrency = 10,
    checker = { enabled = true },
    log = { level = "info" },
}

-- leader key
vim.g.mapleader = " "

-- lazy setup
require("lazy").setup(plugins, opts)

-- require core/ and user/
require("core.options")
require("core.autocmds")
require("core.keymaps")
require("user.ui")


require("tokyonight").setup({
  style = "night",
  transparent = true,
  styles = {
    comments = { italic = true },
    keywords = { italic = true }
  }
})

-- windows only
--terminal: cmd to powershell
vim.o.shell = "powershell.exe"
vim.o.shellcmdflag = "-NoLogo -NoProfile -ExecutionPolicy RemoteSigned -Command"
vim.o.shellquote = ""
vim.o.shellxquote = ""


-- zenhan.exeを利用してInsert→NormalでIMEをOFF
vim.api.nvim_create_autocmd("InsertLeave", {
  callback = function()
    vim.fn.jobstart({ "zenhan.exe", "0" }, { detach = true })
  end,
})

-- Normal→InsertでIMEをONにしたい場合
--vim.api.nvim_create_autocmd("InsertEnter", {
--  callback = function()
--    vim.fn.jobstart({ "zenhan.exe", "1" }, { detach = true })
--  end,
--})


