return {
  "ellisonleao/dotenv.nvim",
  lazy = false,  -- 起動時に確実に読み込む
  config = function()
    require("dotenv").setup({
      enable_on_load = true,  -- Neovim 起動時に .env を自動ロード
      verbose = false,        -- ログを抑制
    })
  end,
}
