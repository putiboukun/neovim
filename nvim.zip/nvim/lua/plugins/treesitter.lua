-- nvim-treesitterの設定
return {
  'nvim-treesitter/nvim-treesitter',
  dependencies = {
    'nvim-treesitter/nvim-treesitter-textobjects',
  },
  build = ":TSUpdate",
  install = function()
    require("nvim-treesitter.install").setup({
      prefer_git = false,
      compilers = { "gcc" },
    })
  end,
  config = function()
    require("nvim-treesitter.configs").setup({
      auto_install = false,
      ensure_installed = {
        "c",
        "cpp",
        "python",
        "r",
        "markdown",
      },
            sync_install = false,
            auto_install = true,
            highlight = { enable = true },
            indent = { enable = true },
      -- そのほかの設定
    })
  end,
}
