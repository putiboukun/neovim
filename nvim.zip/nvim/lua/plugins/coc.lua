return {
  "neoclide/coc.nvim",
  branch = "release",
}
