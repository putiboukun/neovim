-- e.g. plugins/markview.lua
return {
  "OXY2DEV/markview.nvim",
  lazy = false,      -- 遅延読み込みせず即ロード推奨（README にて） :contentReference[oaicite:4]{index=4}
  config = function()
    require("markview").setup({
      preview = {
        enable = true,         -- 自動で有効化するか
        split = {
          enable = false,      -- スプリットウィンドウで表示するか（ターミナル内表示なら false でも可）
        },
        hybrid_modes = {       -- 編集＋プレビュー併用モードなど
          nodewise = false,
          linewise = false,
        },
      },
      -- 必要に応じて設定を下に追加
      highlight = {
        enable = true,
      },
    })
  end,
}
