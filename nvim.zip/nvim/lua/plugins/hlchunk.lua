return {
  {
    "shellRaining/hlchunk.nvim",
    event = { "BufReadPre", "BufNewFile" },
    config = function()
      require("hlchunk").setup({
        indent = {
          enable = true,
          chars = { "│" },
          style = { { fg = "#3b4261" } },
        },
        blank = { enable = false },
        chunk = { enable = false },
        line_num = { enable = false },
      })
    end,
  },
}
