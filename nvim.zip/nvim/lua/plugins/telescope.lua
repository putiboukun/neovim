return {
    {
        "nvim-telescope/telescope.nvim",
        tag = "0.1.8",
        dependencies = {
            "nvim-lua/plenary.nvim",
        },
        opts = {
            defaults = {
                -- 幅と高さを拡げる設定
                layout_strategy = "horizontal",
                layout_config = {
                    horizontal = {
                        width = 0.95,        -- 画面幅の95%
                        height = 0.95,       -- 画面高さの95%
                        preview_width = 0.5, -- プレビューの幅（全体の50%）
                        prompt_position = "bottom",
                    },
                },
                file_ignore_patterns = {
                    "^.git/",
                    "^.cache/",
                    "^.zsh_sessions/",
                    "Library/",
                    "Parallels/",
                    "Movies/",
                    "Music/",
                    "Dropbox/",
                    ".DS_Store",
                },
                vimgrep_arguments = {
                    "rg",
                    "--color=never",
                    "--no-heading",
                    "--with-filename",
                    "--line-number",
                    "--column",
                    "--smart-case",
                    "-uu",
                    "--hidden",
                },
            },
        },
    },
}